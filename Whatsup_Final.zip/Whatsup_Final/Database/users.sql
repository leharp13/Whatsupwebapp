-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 07, 2016 at 06:21 PM
-- Server version: 5.6.31-77.0
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `b12_19233351_whatsup`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block',
  `Location` varchar(55) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Description` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Category` char(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `date`, `created`, `modified`, `status`, `Location`, `Description`, `Category`) VALUES
(34, 'IST440W Class - Hills', '2016-12-13', '2016-12-05 12:15:03', '2016-12-05 12:15:03', 1, 'IST 205', 'Class - last week!', 'Academic Events'),
(33, 'Its already December', '2016-12-01', '2016-11-30 16:23:20', '2016-11-30 16:23:20', 1, 'Penn State Campus', '', 'Other'),
(32, 'IST Graduation', '2016-12-17', '2016-11-30 16:10:23', '2016-11-30 16:10:23', 1, 'BJC @ 9am', 'Lets go Class of 2017!', 'Academic Events'),
(31, 'Final Presentation for 440W', '2016-12-07', '2016-11-30 15:58:26', '2016-11-30 15:58:26', 1, 'Ist Building', 'Final Presentaton for 440 today! make sure its ready to go', 'Other'),
(35, 'Last day of classes!', '2016-12-09', '2016-12-05 12:16:19', '2016-12-05 12:16:19', 1, 'Everywhere', 'PSU Last Day - Finals are next week!', 'Academic Events'),
(36, 'Presenatrion', '2016-12-07', '2016-12-07 16:23:16', '2016-12-07 16:23:16', 1, 'dfg', 'dfg', 'Academic Events');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `Username` char(56) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`) VALUES
('admin', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `userinformation`
--

CREATE TABLE IF NOT EXISTS `userinformation` (
  `First_Name` char(20) NOT NULL,
  `Last_Name` char(20) NOT NULL,
  `Email` char(30) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` varchar(15) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(40) NOT NULL,
  `Preference` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `Preference`) VALUES
('358487d9a2d911', 'hello', 'hello@hello.com', '9a1996efc97181f0aee18321aa3b3b12', 'Academic Events'),
('35845a05815f8d', 'Lauren Anderson', 'lca5073@psu.edu', 'abad0c61ea9d2d99f1bb4ca4bed46c98', 'Sports'),
('358403e462aaa0', 'Vinay Pandya', 'vinaypandya@live.com', 'b712eab767d2a56cb23cbf72c8a9846e', 'Penn State Clubs'),
('3583f5a39de90a', 'Sneha Patel', 'Sneha2294@yahoo.com', 'ae5189855379fa5d94020ce4c6c82d78', 'Penn State Clubs'),
('3583f3d123079d', 'Lehar Pandya', 'leharpandya@gmail.com', '95fbb28feed2a6d20f146093b0d0468a', 'Academic Events');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
