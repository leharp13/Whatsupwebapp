<?php
//connect to mysql database
$con = mysqli_connect("localhost", "root", "root", "Whatsup") or die("Error " . mysqli_error($con));
?>