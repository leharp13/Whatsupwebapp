<?php
session_start();
include_once 'dbconnect.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Whatsup</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" >
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<style type="text/css">
	body {
	background-color: #212121;
}
    .White {
	color: #FFF;
}
    </style>
<meta charset="UTF-8">
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid" style ='background-color: #FFFFFF;'>
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i> </button>
        <a class="navbar-brand page-scroll" href="../index.html"><strong>WHATSUP</strong></a> </div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<?php if (isset($_SESSION['usr_id'])) { ?>
				<li><p class="navbar-text">Signed in as <?php echo $_SESSION['usr_name']; ?></p></li>
				<li><a href="logout.php">Log Out</a></li>
				<?php } else { ?>
				<li><a href="login.php">Login</a></li>
				<li><a href="register.php">Sign Up</a></li>
				<?php } ?>
                
                
			</ul>
		</div>
	</div>
</nav>
<script type="text/javascript">
    window.setTimeout(function() {
        window.location.href='../index.html';
    }, 2000);
</script>

<script src="js/jquery-1.10.2.js"></script> 
<span class="White">Your are Logged out .... You will be redirected in 3 seconds </span>
</body>
</html>

