<?php
//db details
$dbHost = 'sql108.byethost12.com';
$dbUsername = 'b12_19233351';
$dbPassword = 'Whatsup13';
$dbName = 'b12_19233351_whatsup';
 
//Connect and select the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>