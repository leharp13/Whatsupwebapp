<?php
//connect to mysql database
$con = mysqli_connect("sql108.byethost12.com", "b12_19233351", "Whatsup13", "b12_19233351_whatsup") or die("Error " . mysqli_error($con));
?>